#pragma once
#include <iostream>
#include <fstream>
extern std::ofstream file;

class SHIP {
private: int x, y,xMax;
		 bool direction, alive;
		 friend class ENEMY;
public:
	SHIP(int _x, int _y,bool _direction,int _xMax, bool _alive) : x(_x), y(_y), direction(_direction), xMax(_xMax), alive(_alive){}
	int X() { return x; }
	int Y() { return y; }

	int start(int xpos) {
		x = xpos;
		x = x / 2;
		return x;
	
	}
	void movement() {
		if (direction) //left
		{
			x--;
			if (x == 0)
				direction = false;
		}
		else //right
		{
			x++;
			if (x == xMax)
				direction = true;
		}
	}
};