#pragma once
#include "Ship.h"
#include "ShipBullet.h"
class ENEMY{
private: int x, y, xMax, yMax;
		 bool direction, alive;
		 SHIP& av;
		 SHIPBULLET& ab;
public:
	ENEMY(int _x, int _y, int _xMax, int _yMax, bool _direction, bool _alive, SHIP& _av,SHIPBULLET& _ab) : x(_x), y(_y), xMax(_xMax), yMax(_yMax), direction(_direction), alive(_alive), av(_av), ab(_ab){}
	int X() { return x; }
	int Y() { return y; }
	bool Alive() { return alive; }
	void Move() {
		if (alive) {
			if (direction) //left
			{
				x--;
				if ((ab.x == x && ab.y == y && ab.alive == true) || (av.x == x && av.y == y)) { alive = false; }
				else if (x == 0) {
					direction = false;
					y++;
				}
			}
			else //right
			{
				x++;
				if ((ab.x == x && ab.y == y && ab.alive == true) || (av.x == x && av.y == y)) { alive = false; }
				else if (x == xMax) {
					direction = true;
					y++;
				}
			}
		}
	}

};