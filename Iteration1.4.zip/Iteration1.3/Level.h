#pragma once
#include <iostream>
extern std::ofstream file;
class LEVEL{
private: int x, y;
public:
		 LEVEL(int _x, int _y) : x(_x), y(_y){}
	void selectLevel(int input) {
		switch (input) {
		case 1:
			x = 10;
			y = 15;
			break;
		case 2:
			x = 20;
			y = 25;
			break;
		case 3:
			x = 30;
			y = 35;
			break;
		};
	}
	int getLX() { return x; }
	int getLY() { return y; }
	void displayLevel() {
		std::cout << "Current Board: " << y << " , " << x << std::endl;
		file << "Current Board: " << y << " , " << x << std::endl;
	}
};