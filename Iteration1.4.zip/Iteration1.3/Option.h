#pragma once
#include <iostream>
extern std::ofstream file;
class OPTION {
private: int speed, color;
friend class GAME;
public:
	OPTION(int _speed, int _color) : speed(_speed), color(_color) {}
	int getSpeed() { return speed; }
	int getColor() { return color; }
	int setSpeed(int s) {return speed = s; }
	int setColor(int c) {return color = c; }
	void displayOption() {
		std::cout << "WIP add options to control SLEEP(), frequency of enemies (change randomizer), change colour of game layout\n";
		file << "WIP add options to control SLEEP(), frequency of enemies (change randomizer), change colour of game layout\n";
	}
};