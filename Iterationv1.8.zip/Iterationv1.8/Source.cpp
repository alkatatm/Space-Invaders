#include "Game.hpp"
GAME gaming;
int main() {
	gaming.gameOngoing();
	return 0;
}
