#include "Game.hpp"
/* Source Code Summary
This is an attempt to create a space invader game.
Game goes into menu
Player selects a valid input in the menu
 1. To start the game
    game starts with ship at the bottom and enemies moving right to left then down when reaching the wall
	player can move and shoot
	bullet collide with enemy 
	win condition: defeat all enemies
	lose condition: ship collides with an enemy
    game ends, update high score, add into currency, then go back to menu
 2. To select a level 
    choose any unlocked level
	locked level can be unlocked when the previous level has been cleared
 3. To select store
    to select ship's skin
 4. to select and check high scores
    See high scores
 5. to select options
    change UI color
	change speed of the game
 6. To quit
*/
GAME gaming;
int main() {
	gaming.gameOngoing();
	return 0;
}
