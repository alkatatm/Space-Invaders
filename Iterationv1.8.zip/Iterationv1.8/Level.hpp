#ifndef LEVEL_HPP
#define LEVEL_HPP
#include <iostream>
extern std::ofstream file;
/******************************
This class stores the levels 
that creates the gameboard size
*******************************/
class LEVEL{
private: int x, y, unlock;
public:
		 LEVEL(int _x, int _y, int _unlock) : x(_x), y(_y), unlock(_unlock){}
	void selectLevel(int input) {
		if (input > unlock) {
			std::cout << "Unlocked or invalid level\n";
		}
		else {
			switch (input) {
			case 1:
				x = 10;
				y = 15;
				break;
			case 2:
				x = 10;
				y = 25;
				break;
			case 3:
				x = 10;
				y = 35;
				break;
			};
		}
	}
	int getLevel() { return unlock; }
	void setLevel() { unlock++; }
	int getLX() { return x; }
	int getLY() { return y; }
	void displayLevel() {
		std::cout << "Current Board: " << x << " , " << y << std::endl;
		file << "Current Board: " << x << " , " << y << std::endl;
	}
};
#endif 