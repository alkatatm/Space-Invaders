#ifndef COORD_HPP
#define COORD_HPP
/****************************************************

This class is an abstract class to allow
polymorphism for Enemy.hpp, Ship.hpp, ShipBullet.hpp

****************************************************/
class COORD {
private: int x, y, yMAX, xMAX;
public:
	COORD(int _x, int _y, int _xMAX, int _yMAX) { x = _x; y = _y; xMAX = _xMAX; yMAX = _yMAX; }
	virtual void setX(int set) { x = set; }
	virtual void setY(int set) { y = set; }
	virtual int getX() { return x; }
	virtual int getY() { return y; }
	virtual int getYMAX() { return yMAX; }
	virtual int getXMAX() { return xMAX; }
	virtual int minusY() { return y--; }
	virtual int minusX() { return x--; }
	virtual int addY() { return y++; }
	virtual int addX() { return x++; }
	//factory pattern
	virtual void Move(int something) = 0;
};
#endif