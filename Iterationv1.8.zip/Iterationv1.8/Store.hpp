#ifndef STORE_HPP
#define STORE_HPP
#include <iostream>
#include <fstream>
extern std::ofstream file;
/*********************************************************************************
Next iteration: allows player to buy different ship or bullet or enemy "images".
Uses accumalated score as currency to exchange in store
**********************************************************************************/
class STORE {
	//42 88
private: 
	int currency, saved;
	bool ship[3];
	friend class SHIP;
	friend class SHIPBULLET;
public:
	STORE(int _currency, int _saved) : currency(_currency), saved(_saved) {
		ship[0] = true;
		ship[1] = false;
		ship[2] = false;
	}
	void setCurrency(int add) { currency = currency + add;}
	int getSaved() { return saved; }
	//control character
	void setSaved() {
		saved++;
		bool loop = true;
		while (loop){
			if (saved == 3)//loop back from max
				saved = 0;
			else if (!ship[saved]) //iterate until reaches a valid ship skin
				saved++;
			else //break when found a valid ship skin
				break;
	}
}
	void storeBuy() {
		int input;
		std::cout << "Input a number available below to either buy; each cost 1000 spacebacks\nCurrent Currency: "<< currency;
		file << "Input a number available below to either buy; each cost 1000 spacebacks\nCurrent Currency: " << currency;
		std::cout << "\n1. X, * \t" << ship[0] << "\n2. Y, + \t" << ship[1] << "\n3. Z, , \t" << ship[2] << std::endl;
		file << "\n1. X, * \t" << ship[0] << "\n2. Y, + \t" << ship[1] << "\n3. Z, , \t" << ship[2] << std::endl;
		std::cin >> input;
		if (ship[input-1] == true) {
			std::cout << "Already bought!\n";
			file << "Already bought!\n";
		}
		else if (currency < 1000) {
			std::cout << "Not enough spacebucks!\n";
			file << "Not enough spacebucks!\n";
		}
		else {
			ship[input-1] = true;
			saved = input-1;
			currency -= 1000;
			std::cout << "Bought number " << input << "!\nNow Equipped!\n";
			file << "Bought number " << input << "!\nNow Equipped!\n";
		}
	}
};
#endif