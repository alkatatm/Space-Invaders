#include "Game.h"
GAME gaming;
int main() {
	gaming.gameOngoing();
	return 0;
}
