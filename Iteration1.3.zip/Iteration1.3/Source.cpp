#include <iostream>
#include <chrono>		
#include <thread>		    
#include <fstream>
#include "Ship.h"
#include "ShipBullet.h"
#include "Enemy.h"
#define clear() printf("\033[H\033[J") //clear the terminal

int main() {
	std::ofstream file;
	file.open("data.txt");
	int xAxis = 10; //rows
	int yAxis = 12; //columns
	bool gameLoop = true;//loop game
	int input; //menu input
	bool menu = true; //loop the menu
	int level = 1; //select level
	char **game; //create gameboard
	char movechar;
	while (menu) {
		//Create gameboard
		game = new char*[yAxis];
		for (int i = 0; i < yAxis; i++)
			game[i] = new char[xAxis];

		for (int i = 0; i < yAxis; i++) {
			for (int j = 0; j < xAxis; j++)
				game[i][j] = ' ';
		}
		//Start position of ship
		SHIP player((xAxis / 2 -2), (yAxis - 1), false, xAxis,true);
		std::cout << player.X() << player.Y() << std::endl;

		//Initalize ship bullet position
		SHIPBULLET bullet(xAxis, yAxis - 2, 1, false, false);
		ENEMY enemy1(xAxis/2,0,xAxis,yAxis,false, true,player,bullet);
		ENEMY enemy2(xAxis/2 - 1, 0, xAxis, yAxis, false, true,player,bullet);
		ENEMY enemy3(xAxis / 2 - 2, 0, xAxis, yAxis, false, true,player,bullet);
		clear();
		std::cout << "Current Board: " << yAxis << " , " << xAxis << std::endl;
		file << "Current Board: " << yAxis << " , " << xAxis << std::endl;
		std::cout << "MENU input the number corresponding the word next to it:\n\n1.Play\n2.Select Level\n3.Store\n4.Score\n5.Options\n6.Exit\n";
		file << "MENU input the number corresponding the word next to it:\n\n1.Play\n2.Select Level\n3.Store\n4.Score\n5.Options\n6.Exit\n";
		std::cin >> input;
		while (input > 5 && input < 0) {
			std::cin >> input;
		}
		switch (input) {
		case 1://game
			//Keep the game going
			while (gameLoop) {
				//cin.ignore();
				//clear previous position
				game[player.Y()][player.X()] = ' ';
				//move ship left and right
				do{
					std::cin >> movechar;
					if (movechar == 'a')
						break;
					if (movechar == 'd')
						break;
					if (movechar == 's' && !bullet.Start())
						break;
				} while (movechar != 'a' || movechar != 'd');
				player.movement(movechar);
				//display ship in gameboard
				game[player.Y()][player.X()] = 'X';

				//move bullet up
				if (bullet.Start() == true) {
					std::cout << "Bullet Position: " << bullet.X() << " , " << bullet.Y() << std::endl;
					file << "Bullet Position: " << bullet.X() << " , " << bullet.Y() << std::endl;
					game[bullet.Y()][bullet.X()] = ' ';
					bullet.bulletMove(yAxis);
					if (bullet.Y() != 0 && bullet.Y() != yAxis - 2)
						game[bullet.Y()][bullet.X()] = '^';
				}
				//start bullet
				else if (!bullet.Start() && movechar == 's') {
					std::cout << "In Bullet Time" << std::endl;
					file << "In Bullet Time" << std::endl;
					bullet.bulletInitialize(player.X());
				}
				//randomize when bullet spawns
				else {
					std::cout << "Bullet: INACTIVE" << std::endl;
					file << "Bullet: INACTIVE" << std::endl;
					//bullet.randomize(player.X());
				}

				//clear previous position
				game[enemy1.Y()][enemy1.X()] = ' ';
				//move ship left and right
				enemy1.Move();
				//display ship in gameboard
				game[enemy1.Y()][enemy1.X()] = 'O';

				//clear previous position
				game[enemy2.Y()][enemy2.X()] = ' ';
				//move ship left and right
				enemy2.Move();
				//display ship in gameboard
				game[enemy2.Y()][enemy2.X()] = 'O';

				//clear previous position
				game[enemy3.Y()][enemy3.X()] = ' ';
				//move ship left and right
				enemy3.Move();
				//display ship in gameboard
				game[enemy3.Y()][enemy3.X()] = 'O';

				if (!enemy1.Alive() && !enemy2.Alive() && !enemy3.Alive()) {
					std::cout << "WIN\n";
					file << "WIN\n";
					system("pause");
					break;
				}
				else if (!player.Alive()) {
					std::cout << "LOSE\n";
					file << "LOSE\n";
					system("pause");
					break;
				}
				//display ship coordinates
				std::cout << "Ship position at: " << player.X() << " , " << player.Y() << std::endl;
				file << "Ship position at: " << player.X() << " , " << player.Y() << std::endl;

				//display enemy coordinates
				std::cout << "Enemy position at: " << enemy1.X() << " , " << enemy1.Y() << std::endl;
				file << "Enemy position at: " << enemy1.X() << " , " << enemy1.Y() << std::endl;

				std::cout << "Enemy position at: " << enemy2.X() << " , " << enemy2.Y() << std::endl;
				file << "Enemy position at: " << enemy2.X() << " , " << enemy2.Y() << std::endl;

				std::cout << "Enemy position at: " << enemy3.X() << " , " << enemy3.Y() << std::endl << std::endl;
				file << "Enemy position at: " << enemy3.X() << " , " << enemy3.Y() << std::endl << std::endl;

				//display game
				for (int i = 0; i < yAxis; i++) {
					for (int j = 0; j < xAxis; j++) {
						std::cout << game[i][j] << ' ';
					}
					std::cout << std::endl;
				}
				system("pause");
				std::this_thread::sleep_for(std::chrono::milliseconds(200));
				clear();
			}
			clear();
			std::cout << "GAME OVER\n";
			file << "GAME OVER\n";
			system("pause");
			break;
		case 2://level
			std::cout << "Select board size number:\n\n1.10x12\n2.20x22\n3.30x32\n\n";
			file << "Select board size number:\n\n1.10x12\n2.20x22\n3.30x32\n\n";
			std::cin >> level;
			if (level == 1) {
				std::cout << "Current board size is 10 x 12\n\n";
				file << "Current board size is 10 x 12\n\n";
				xAxis = 10;
				yAxis = 12;
			}
			else if (level == 2) {
				std::cout << "Current board size is 20 x 22\n\n";
				file << "Current board size is 20 x 22\n\n";
				xAxis = 20;
				yAxis = 22;
			}
			else if (level == 3) {
				std::cout << "Current board size is 30 x 32\n\n";
				file << "Current board size is 30 x 32\n\n";
				xAxis = 30;
				yAxis = 32;
			}	
			system("pause");
			break;
		case 3://store
			std::cout << "WIP to use global score and buy ships or colors or change bullet character\n";
			file << "WIP to use global score and buy ships or colors or change bullet character\n";
			system("pause");
			break;
		case 4://score
			std::cout << "WIP to save ingame score to global score\n";
			file << "WIP to save ingame score to global score\n";
			system("pause");
			break;	
		case 5://options
			std::cout << "WIP add options to control SLEEP(), frequency of enemies (change randomizer), change colour of game layout\n";
			file << "WIP add options to control SLEEP(), frequency of enemies (change randomizer), change colour of game layout\n";
			system("pause");
			break;
		case 6://quit
			std::cout << "QUIT\n";
			file << "QUIT\n";
			menu = false;
			break;
		}
		delete [] game;
	}
	file.close();
	return 0;
}