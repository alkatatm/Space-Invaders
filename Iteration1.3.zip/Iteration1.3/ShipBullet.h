#pragma once
#include <time.h>   
#include <iostream>

class SHIPBULLET {
private: int x, y, randnum;
		 bool start, alive;
		 friend class ENEMY;
public:
	SHIPBULLET(int _x, int _y,int _randnum, bool _start, bool _alive) : x(_x), y(_y), randnum(_randnum), start(_start), alive(_alive){}
	int X() { return x; }
	int Y() { return y; }
	int randNum() { return randnum; }
	bool Start() { return start; }
	bool Alive() { return alive; }
	void randomize(int xpos) {
		randnum = rand() % 5;
		x = xpos;
	}
	void bulletMove(int yMax) {
		if (y == 0 || alive == false) {
			start = false;
			//alive = false;
			y = yMax- 2;
		}
		else {
			y--;
		}
	}
	void bulletInitialize(int xpos) {
		start = true;
		alive = true;
		randnum++;
		x = xpos;
	}
};