#pragma once
#include <iostream>
#include <fstream>
extern std::ofstream file;

class SHIP {
private: int x, y,xMax;
		 bool direction, alive;
		 friend class ENEMY;
public:
	SHIP(int _x, int _y,bool _direction,int _xMax, bool _alive) : x(_x), y(_y), direction(_direction), xMax(_xMax), alive(_alive){}
	int X() { return x; }
	int Y() { return y; }
	bool Alive() { return alive; }

	int start(int xpos) {
		x = xpos;
		x = x / 2;
		return x;
	
	}
	void movement(char input) {
		if (input == 'a') //left
		{
			if (x > 0)
				x--;
		}
		else if (input == 'd')//right
		{
			if (x < xMax-1)
				x++;
		}
	}
};