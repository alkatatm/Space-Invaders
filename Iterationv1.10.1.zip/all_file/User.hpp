#ifndef USER_HPP
#define USER_HPP
#include <iostream>
#include <string>

/********************************
Holds the login
Next iteration: store in database
********************************/
class USER {
private: std::string username, password;
public:
	USER(std::string _username,std::string _password) : username(_username), password(_password) {}
	void setUsername(std::string u) { username = u; }
	void setPassword(std::string p) { password = p; }
	std::string getUsername() { return username; }
	std::string getPassword() { return password; }
};
#endif