#ifndef SHIPBULLET_HPP
#define SHIPBULLET_HPP
#include <time.h>   
#include <iostream>
#include "Coord.hpp"
extern std::ofstream file;
/************************************
This class controls bullet that 
exist on the gameboard one at a time
and "destroyed" once out of bound
*************************************/
class SHIPBULLET: public COORD {
private: int randnum;
		 bool start, alive;
		 friend class ENEMY;
public:
	SHIPBULLET(int _x, int _y, int _randnum, bool _start, bool _alive, int _xMax, int _yMax) : COORD(_x,_y,_xMax,_yMax), randnum(_randnum), start(_start), alive(_alive) {}
	int randNum() { return randnum; }
	bool Start() { return start; }
	bool Alive() { return alive; }
	void randomize(int xpos) {
		randnum = rand() % 5;
		setX(xpos);
	}
	void Move(int yMax) {
		if (getY() == 0 || alive == false) {
			start = false;
			setY(getYMAX()-2);
		}
		else {
			minusY();
		}
	}
	void bulletInitialize(int xpos) {
		start = true;
		alive = true;
		randnum++;
		setX(xpos);
	}
};
#endif