#ifndef LOGIN_HPP
#define LOGIN_HPP
#include <iostream>
#include <string>
#include <vector>
#include "User.hpp"

extern std::ofstream file;
/********************************
Holds the login
Next iteration: store in database
********************************/
class LOGIN {
private: std::string user, pass;
		 std::string line;
		 std::ifstream userData;
public:
	LOGIN(std::string _user, std::string _pass) : user(_user), pass(_pass){}
	void setUser(std::string u) { user = u; }
	void setPass(std::string p) { pass = p; }
	std::string getUser() { return user; }
	std::string getPass() { return pass; }

	std::string UserPass() {
		std::string loginInfo = getUser() + " " + getPass();
		return loginInfo;
	}

	void authCheck(std::string& loginInfo, bool& success) {
		userData.open("user.txt");
		if (userData.is_open())
		{
            std::vector<USER> users;
            while (!userData.eof()) {
                std::string username, password;
                userData >> username >> password;
                USER user(username, password);
                users.push_back(user);
            }
            
            for (USER user : users) {
                std::string info = user.getUsername() + " " + user.getPassword();
                if (!info.compare(loginInfo)) {
                    success = true;
                    break;
                }
                else
                    success = false;
            }
			
			userData.close();
			if (success)
			{
				return;
			}
			else
			{
				std::cout << "\nIncorrect Username or Password\n\n";
				loginInfo = "";
				login();
			}
			userData.close();
		}
		else
			std::cout << "Unable to open user.txt file.\n";
	}

	void login() {
		std::cout << "Sign into Space Invader\n\nUsername: ";
        std::getline(std::cin, user);
		std::cout << "Password: ";
		std::getline(std::cin, pass);
		setUser(user);
		setPass(pass);
	}
};
#endif
