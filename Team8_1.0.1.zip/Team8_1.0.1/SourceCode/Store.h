#pragma once
#include <iostream>
#include <fstream>
extern std::ofstream file;
/*********************************************************************************
Next iteration: allows player to buy different ship or bullet or enemy "images".
Uses accumalated score as currency to exchange in store
**********************************************************************************/
class STORE {
friend class GAME;
public:
	STORE() {}
	~STORE() {}
	void storeWIP() {
		std::cout << "WIP to use global score and buy ships or colors or change bullet character\n";
		file << "WIP to use global score and buy ships or colors or change bullet character\n";
	}

};