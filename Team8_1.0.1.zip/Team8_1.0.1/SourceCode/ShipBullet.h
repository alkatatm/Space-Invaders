#pragma once
#include <time.h>   
#include <iostream>
extern std::ofstream file;
/************************************
This class controls bullet that 
exist on the gameboard one at a time
and "destroyed" once out of bound
*************************************/
class SHIPBULLET {
private: int x, y, randnum;
		 bool start, alive;
		 friend class ENEMY;
public:
	SHIPBULLET(int _x, int _y,int _randnum, bool _start, bool _alive) : x(_x), y(_y), randnum(_randnum), start(_start), alive(_alive){}
	int X() { return x; }
	int Y() { return y; }
	void setX(int x1) { x = x1; }
	void setY(int y1) { y = y1; }
	int randNum() { return randnum; }
	bool Start() { return start; }
	bool Alive() { return alive; }
	void randomize(int xpos) {
		randnum = rand() % 5;
		x = xpos;
	}
	void bulletMove(int yMax) {
		if (y == 0 || alive == false) {
			start = false;
			//alive = false;
			y = yMax- 2;
		}
		else {
			y--;
		}
	}
	void bulletInitialize(int xpos) {
		start = true;
		alive = true;
		randnum++;
		x = xpos;
	}
};