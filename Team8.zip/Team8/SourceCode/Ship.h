#pragma once
#include <iostream>
#include <fstream>
extern std::ofstream file;
/*************************************************
This class creates a ship that allows a player to
control moving left and right as well as to shoot
**************************************************/
class SHIP {
private: int x, y,xMax;
		 bool direction, alive;
		 friend class ENEMY;
		 friend class GAME;
public:
	SHIP(int _x, int _y,bool _direction,int _xMax, bool _alive) : x(_x), y(_y), direction(_direction), xMax(_xMax), alive(_alive){}
	int X() { return x; }
	int Y() { return y; }
	void setX(int x1) {  x = x1; }
	void setY(int y1) {  y = y1; }
	bool Alive() { return alive; }

	void movement(char input) {
		if (input == 'a') //left
		{
			if (x > 0)
				x--;
		}
		else if (input == 'd')//right
		{
			if (x < xMax-1)
				x++;
		}
	}
};