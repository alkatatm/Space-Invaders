#pragma once
#include "Ship.h"
#include "ShipBullet.h"
extern std::ofstream file;
/***************************************************
This class controls the enemies and collisions
The enemies move right to left
Check each  coordinate after if there's a collision
if so then stop moving
***************************************************/
class ENEMY{
private: int x, y, xMax, yMax;
		 bool direction, alive;
		 SHIP& av;
		 SHIPBULLET& ab;
public:
	ENEMY(int _x, int _y, int _xMax, int _yMax, bool _direction, bool _alive, SHIP& _av,SHIPBULLET& _ab) : x(_x), y(_y), xMax(_xMax), yMax(_yMax), direction(_direction), alive(_alive), av(_av), ab(_ab){}
	int X() { return x; }
	int Y() { return y; }
	void setX(int x1) { x = x1; }
	void setY(int y1) { y = y1; }
	bool Alive() { return alive; }
	void Move() {
		if (alive) {
			if (direction) //left
			{
				x--;
				checkCollision();
				if (x == 0) {
					direction = false;
					y++;
				}
			}
			else //right
			{
				x++;
				checkCollision();
				if (x == xMax) {
					direction = true;
					y++;
				}
			}
		}
	}
	void checkCollision() {
		if (ab.x == x && ab.y == y) { ab.alive = false; alive = false; }
		else if (av.x == x && av.y == y) { av.alive = false; alive = false; }
	}
	void display() {
		if (alive) {
			std::cout << "Enemy position at: " << x << " , " << y << std::endl;
			file << "Enemy position at: " << x << " , " << y << std::endl;
		}
		else {
			std::cout << "COLLIDED at: " << x << " , " << y << std::endl;
			file << "COLLIDED at: " << x << " , " << y << std::endl;
		}
	}
};
