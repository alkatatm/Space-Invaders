#pragma once
#include <iostream>
extern std::ofstream file;
/********************************************
Next iteration: This class controls the score
Affects score when hitting the enemy
*********************************************/
class SCORE {
public:
	void scoreWIP(){
		std::cout << "WIP to save ingame score to global score\n";
		file << "WIP to save ingame score to global score\n";
	}


};