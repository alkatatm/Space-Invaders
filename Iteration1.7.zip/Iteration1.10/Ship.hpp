#ifndef SHIP_HPP
#define SHIP_HPP
#include <iostream>
#include <fstream>
#include "Coord.hpp"
extern std::ofstream file;
/*************************************************
This class creates a ship that allows a player to
control moving left and right as well as to shoot
**************************************************/
class SHIP: public COORD {
private: 
		 bool direction, alive;
		 friend class ENEMY;
		 friend class GAME;
public:
	SHIP(int _x, int _y,bool _direction,int _xMax, bool _alive, int _yMax) : COORD(_x,_y, _xMax, _yMax), direction(_direction), alive(_alive){}
	bool Alive() { return alive; }

	void Move(int input) {
		if (input == 97) //left
		{
			if (getX() > 0)
				minusX();
		}
		else if (input == 100)//right
		{
			if (getX() < getXMAX() - 1)
				addX();
		}
	}
};
#endif