#ifndef SCORE_HPP
#define SCORE_HPP
#include <iostream>
extern std::ofstream file;
/********************************************
Next iteration: This class controls the score
Affects score when hitting the enemy
*********************************************/
class SCORE {
private:
	int score, hiScore[5];
	friend class ENEMY;
public:
	SCORE() {
		score = 0;
		hiScore[5] = { 0 };
	}
	void scoreIncrease(){
		score += 100;
	}
	int getScore() {
		return score;
	}
	void replace() {
		for (int i = 0; i < 5; i++) {
			if (score > hiScore[i]) {
				//MAKE EVERY SCORE PUSHED DOWN
				hiScore[i] = score;
				break;
			}
		}
		score = 0;
	}
	void highScore() {
		for (int i = 0; i < 5; i++) {
			std::cout << i+1 << ".\t\t\t" << hiScore[i] << std::endl;
		}
	}
};
#endif