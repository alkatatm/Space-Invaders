#pragma once
#include <iostream>
#include <string>
extern std::ofstream file;
class OPTION {
private: int speed; 
		 std::string color;
friend class GAME;
public:
	OPTION(int _speed, std::string _color) : speed(_speed), color(_color) {}
	int getSpeed() { return speed; }
	std::string getColor() { return color; }
	int setSpeed(int s) {return speed = s; }
	std::string setColor(int c) {return color = c; }
	void displayOption() {
		int choose;
		std::cout << "1. Speed\n2. Color\n";
		file << "1. Speed\n2. Color\n";
		do {
			std::cin >> choose;
		} while (choose < 1 || choose > 2);
		switch (choose) {
		case 1:
			std::cout << "1. How much speed?\n";
			file << "1. How much speed?\n";
			std::cin >> choose;
			speed = choose;
			break;
		case 2:
			std::cout << "1. Red\n2. Blue\n3. Green\n4. White\n";
			file << "1. Red\n2. Blue\n3. Green\n4. White\n";
			do {
				std::cin >> choose;
			} while (choose < 1 || choose > 4); 
			switch (choose) {
			case 1:
				color = "COLOR 0C";
				break;
			case 2:
				color = "COLOR 0B";
				break;
			case 3: 
				color = "COLOR 0A";
				break;
			case 4:
				color = "COLOR 0F";
				break;
			}
			
			break;
		}
	}
};