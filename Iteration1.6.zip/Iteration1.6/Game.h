#pragma once
#include <iostream>
#include <chrono>		
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <thread>		    
#include <fstream>
#include "Ship.h"
#include "ShipBullet.h"
#include "Enemy.h"
#include "Level.h"
#include "Option.h"
#include "Store.h"
#include "Score.h"
#include "Login.h"
#define clear() printf("\033[H\033[J") //clear the terminal
bool gameLoop = true;//loop game
bool menu = true;
char **game;
LEVEL level(10, 15);
LOGIN logging("a","b");
SHIP player((level.getLX() / 2 - 2), (level.getLY() - 1), false, level.getLX(), true);
SHIPBULLET bullet(level.getLX(), level.getLY() - 2, 1, false, false);
ENEMY enemy1(level.getLX()/2, 0, level.getLX(), level.getLY(), false, true, player, bullet);
ENEMY enemy2(level.getLX() / 2 - 1, 0, level.getLX(), level.getLY(), false, true, player, bullet);
ENEMY enemy3(level.getLX() / 2 - 2, 0, level.getLX(), level.getLY(), false, true, player, bullet);
OPTION opt(10,"COLOR 0F");
STORE store;
SCORE score;
std::ofstream file;

class GAME {
	
public:
	GAME() {}
	~GAME() {}
	void gameOngoing() {
		//LOGIN
		std::string acc;
		std::cout << "Sign into Space Invader\n\nUsername: ";
		std::cin >> acc;
		logging.setUser(acc);
		std::cout << "Password: ";
		std::cin >> acc;
		logging.setPass(acc);
		while (menu) {
			std::string cmdd(opt.getColor());
			system(cmdd.c_str());
			//Create gameboard
			game = new char*[level.getLY()];
			for (int i = 0; i < level.getLY(); i++)
				game[i] = new char[level.getLX()];

			for (int i = 0; i < level.getLY(); i++) {
				for (int j = 0; j < level.getLX(); j++)
					game[i][j] = ' ';
			}

			clear();
			std::cout << "Welcome Back " << logging.getUser();
			file << "Welcome Back " << logging.getUser();
			std::cout << "\nMENU input the number corresponding the word next to it:\n\n1.Play\n2.Select Level\n3.Store\n4.Score\n5.Options\n6.Exit\n";
			file << "\nMENU input the number corresponding the word next to it:\n\n1.Play\n2.Select Level\n3.Store\n4.Score\n5.Options\n6.Exit\n";
			int input;
			std::cin >> input;
			while (input > 6 && input < 0) {
				std::cin >> input;
			}
			menuGame(input);
			delete[] game;
		}
	}
	void gameStart() {
		//Keep the game going
		file.open("data.txt");
		char movechar;
		while (gameLoop) {
			//cin.ignore();
			//clear previous position
			game[player.Y()][player.X()] = ' ';
			//move ship left and right
			do {

				std::cin >> movechar;
				if (direction(movechar))
					break;
			} while (movechar != 'a' || movechar != 'd');
			player.movement(movechar);
			//display ship in gameboard
			game[player.Y()][player.X()] = 'X';

			//move bullet up
			if (bullet.Start() == true) {
				std::cout << "Bullet Position: " << bullet.X() << " , " << bullet.Y() << std::endl;
				file << "Bullet Position: " << bullet.X() << " , " << bullet.Y() << std::endl;
				game[bullet.Y()][bullet.X()] = ' ';
				bullet.bulletMove(level.getLY());
				if (bullet.Y() != 0 && bullet.Y() != level.getLY() - 2)
					game[bullet.Y()][bullet.X()] = '^';
			}
			//start bullet
			else if (!bullet.Start() && movechar == 's') {
				std::cout << "In Bullet Time" << std::endl;
				file << "In Bullet Time" << std::endl;
				bullet.bulletInitialize(player.X());
			}
			//randomize when bullet spawns
			else {
				std::cout << "Bullet: INACTIVE" << std::endl;
				file << "Bullet: INACTIVE" << std::endl;
				//bullet.randomize(player.X());
			}

			//clear previous position
			game[enemy1.Y()][enemy1.X()] = ' ';
			//move ship left and right
			enemy1.Move();
			//display ship in gameboard
			game[enemy1.Y()][enemy1.X()] = 'O';

			//clear previous position
			game[enemy2.Y()][enemy2.X()] = ' ';
			//move ship left and right
			enemy2.Move();
			//display ship in gameboard
			game[enemy2.Y()][enemy2.X()] = 'O';

			//clear previous position
			game[enemy3.Y()][enemy3.X()] = ' ';
			//move ship left and right
			enemy3.Move();
			//display ship in gameboard
			game[enemy3.Y()][enemy3.X()] = 'O';

			if (!enemy1.Alive() && !enemy2.Alive() && !enemy3.Alive()) {
				std::cout << "WIN\n";
				file << "WIN\n";
				system("pause");
				break;
			}
			else if (!player.Alive()) {
				std::cout << "LOSE\n";
				file << "LOSE\n";
				system("pause");
				break;
			}
			display();
			system("pause");
			std::this_thread::sleep_for(std::chrono::milliseconds(opt.getSpeed()));
			clear();
		}

	}
	void menuGame(int input) {
		switch (input) {
		case 1://game
			gameStart();
			clear();
			std::cout << "GAME OVER\n";
			file << "GAME OVER\n";
			system("pause");
			break;
		case 2://level
			int levelx;
			do {
				std::cout << "Select board size number:\n\n1.10x15\n2.10x25\n3.10x35\n\n";
				file << "Select board size number:\n\n1.10x15\n2.10x25\n3.10x35\n\n";
				std::cin >> levelx;
			} while (input < 1 || input > 3);
			select(levelx);
			level.displayLevel();
			player.setX(level.getLX()/2-2); player.setY(level.getLY()-1);
			bullet.setY(level.getLY() - 2);
			system("pause");
			break;
		case 3://store
			store.storeWIP();
			system("pause");
			break;
		case 4://score
			score.scoreWIP();
			system("pause");
			break;
		case 5://options
			opt.displayOption();
			system("pause");
			break;
		case 6://quit
			std::cout << "QUIT\n";
			file << "QUIT\n";
			menu = false;
			break;
		}
		file.close();
	}
	void select(int levelp) {
		level.selectLevel(levelp);
	}
	

	void display() {
		//display ship coordinates
		std::cout << "Ship position at: " << player.X() << " , " << player.Y() << std::endl;
		file << "Ship position at: " << player.X() << " , " << player.Y() << std::endl;

		//display enemy coordinates
		enemy1.display();
		enemy2.display();
		enemy3.display();

		//display game
		for (int i = 0; i < level.getLY(); i++) {
			for (int j = 0; j < level.getLX(); j++) {
				std::cout << game[i][j] << ' ';
			}
			std::cout << std::endl;
		}

	}
	bool direction(char move) {

		if (move == 'a')
			return true;
		if (move == 'd')
			return true;
		if (move == 's' && !bullet.Start())
			return true;
		return false;
	}





};