#ifndef GAME_HPP
#define GAME_HPP
#include <iostream>
#include <chrono>		
#include <string>
#include <thread>		    
#include <fstream>
#include "Ship.hpp"
#include "ShipBullet.hpp"
#include "Enemy.hpp"
#include "Level.hpp"
#include "Option.hpp"
#include "Store.hpp"
#include "Score.hpp"
#include "Login.hpp"
#define clear() printf("\033[H\033[J") //clear the terminal
bool gameLoop = true;//loop game
bool menu = true;
char **game;
//enemy ship bullet

LEVEL level(10, 15,1);
LOGIN logging("a","b");
SCORE score;
SHIP player((level.getLX() / 2 - 2), (level.getLY() - 1), false, level.getLX(), true,level.getLY());
SHIPBULLET bullet(level.getLX(), level.getLY() - 2, 1, false, false, level.getLX(), level.getLY());
ENEMY enemy1(level.getLX()/2, 0, level.getLX(), level.getLY(), false, true, player, bullet,score);
ENEMY enemy2(level.getLX() / 2 - 1, 0, level.getLX(), level.getLY(), false, true, player, bullet, score);
ENEMY enemy3(level.getLX() / 2 - 2, 0, level.getLX(), level.getLY(), false, true, player, bullet, score);
OPTION opt(10,"COLOR 0F");
STORE store(100000,0);

std::ofstream file;

/******************************************************
This public class executes all the other classes 
GAME controls the game and login
Holds the objects that affects the menu and game
******************************************************/

class GAME {
	
public:
	GAME() {}
	~GAME() {}
	void gameOngoing() {
		//LOGIN
		std::string user;
		std::string pass;
		std::string loginInfo; 
		bool success = false;

		do
		{

			logging.login();
			loginInfo = logging.UserPass();
			logging.authCheck(loginInfo, success);
		} while (!success);
		
		while (menu) {
			std::string cmdd(opt.getColor());
			system(cmdd.c_str());
			//Create gameboard
			game = new char*[level.getLY()];
			for (int i = 0; i < level.getLY(); i++)
				game[i] = new char[level.getLX()];

			for (int i = 0; i < level.getLY(); i++) {
				for (int j = 0; j < level.getLX(); j++)
					game[i][j] = ' ';
			}

			clear();
			std::cout << "Welcome " << user;
			file << "Welcome " << user;
			std::cout << "\nMENU input the number corresponding the word next to it:\n\n1.Play\n2.Select Level\n3.Store\n4.Score\n5.Options\n6.Logout\n7.Exit\n";
			file << "\nMENU input the number corresponding the word next to it:\n\n1.Play\n2.Select Level\n3.Store\n4.Score\n5.Options\n6.Logout\n7.Exit\n";
			int input;
			std::cin >> input;
			while (input > 7 && input < 0) {
				std::cin >> input;
			}
			menuGame(input);
			delete[] game;
		}
	}
	void gameStart() {
		//Keep the game going
		file.open("data.txt");
		char movechar;
		while (gameLoop) {
			//clear previous position
			game[player.getY()][player.getX()] = ' ';
			//move ship left and right
			do {
				std::cin >> movechar;
				if (direction(movechar))
					break;
			} while (movechar != 'a' || movechar != 'd');
			player.Move(int(movechar));

			//display score
			std::cout << "Score : " << score.getScore() << std::endl;
			file << "Score : " << score.getScore() << std::endl;

			//display ship in gameboard
			game[player.getY()][player.getX()] = char(store.getSaved()+88);

			//move bullet up
			if (bullet.Start() == true) {
				std::cout << "Bullet Position: " << bullet.getX() << " , " << bullet.getY() << std::endl;
				file << "Bullet Position: " << bullet.getX() << " , " << bullet.getY() << std::endl;
				game[bullet.getY()][bullet.getX()] = ' ';
				bullet.Move(level.getLY());
				if (bullet.getY() != 0 && bullet.getY() != level.getLY() - 2)
					game[bullet.getY()][bullet.getX()] = char(store.getSaved()+42);
			}
			//start bullet
			else if (!bullet.Start() && movechar == 's') {
				std::cout << "In Bullet Time" << std::endl;
				file << "In Bullet Time" << std::endl;
				bullet.bulletInitialize(player.getX());
			}
			//randomize when bullet spawns
			else {
				std::cout << "Bullet: INACTIVE" << std::endl;
				file << "Bullet: INACTIVE" << std::endl;
			}

			//clear previous position
			game[enemy1.getY()][enemy1.getX()] = ' ';
			//move ship left and right
			enemy1.Move(0);
			//display ship in gameboard
			game[enemy1.getY()][enemy1.getX()] = 'O';

			//clear previous position
			game[enemy2.getY()][enemy2.getX()] = ' ';
			//move ship left and right
			enemy2.Move(0);
			//display ship in gameboard
			game[enemy2.getY()][enemy2.getX()] = 'O';

			//clear previous position
			game[enemy3.getY()][enemy3.getX()] = ' ';
			//move ship left and right
			enemy3.Move(0);
			//display ship in gameboard
			game[enemy3.getY()][enemy3.getX()] = 'O';

			//Win condition if all enemies are gone
			if (!enemy1.Alive() && !enemy2.Alive() && !enemy3.Alive()) {
				std::cout << "WIN\n";
				file << "WIN\n";
				store.setCurrency(score.getScore());
				level.setLevel();
				system("pause");
				break;
			}
			//Lose condition when Ship is gone
			else if (!player.Alive()) {
				std::cout << "LOSE\n";
				file << "LOSE\n";
				system("pause");
				break;
			}
			//display board
			display();
			system("pause");
			std::this_thread::sleep_for(std::chrono::milliseconds(opt.getSpeed()));
			clear();
		}

	}
	void menuGame(int input) {
		switch (input) {
		case 1://game
			gameStart();
			clear();
			std::cout << "GAME OVER\n";
			file << "GAME OVER\n";
			system("pause");
			break;
		case 2://level
			int levelx;
			do {
				std::cout << "Select board size number:\n\n1.10x15\n2.10x25\n3.10x35\n\n";
				file << "Select board size number:\n\n1.10x15\n2.10x25\n3.10x35\n\n";
				std::cin >> levelx;
			} while (levelx < 1 || levelx > 3);
			select(levelx);
			level.displayLevel();
			player.setX(level.getLX()/2-2); player.setY(level.getLY()-1);
			bullet.setY(level.getLY() - 2);
			system("pause");
			break;
		case 3://store
			store.storeBuy();
			system("pause");
			break;
		case 4://score
			score.highScore();
			system("pause");
			break;
		case 5://options
			opt.displayOption();
			system("pause");
			break;
		case 6://logout
			std::cout << "Logged out\n\n";
			file << "Logged out\n\n";
			gameOngoing();
		case 7://quit
			std::cout << "QUIT\n";
			file << "QUIT\n";
			menu = false;
			break;
		}
		file.close();
	}
	void select(int levelp) {
		level.selectLevel(levelp);
	}
	
	void display() {
		//display ship coordinates
		std::cout << "Ship position at: " << player.getX() << " , " << player.getY() << std::endl;
		file << "Ship position at: " << player.getX() << " , " << player.getY() << std::endl;

		//display enemy coordinates
		enemy1.display();
		enemy2.display();
		enemy3.display();

		//display game
		for (int i = 0; i < level.getLY(); i++) {
			for (int j = 0; j < level.getLX(); j++) {
				std::cout << game[i][j] << ' ';
			}
			std::cout << std::endl;
		}

	}
	bool direction(char move) {
		if (move == 'a')
			return true;
		if (move == 'd')
			return true;
		if (move == 's' && !bullet.Start())
			return true;
		if (move == 'w'){
			store.setSaved();
		return true;
	}
		return false;
	}





};
#endif