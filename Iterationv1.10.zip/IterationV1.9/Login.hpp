#ifndef LOGIN_HPP
#define LOGIN_HPP
#include <iostream>
#include <string>

extern std::ofstream file;
/********************************
Holds the login
Next iteration: store in database
********************************/
class LOGIN {
private: std::string user, pass;
		 std::string line;
		 std::ifstream userData;
public:
	LOGIN(std::string _user, std::string _pass) : user(_user), pass(_pass){}
	void setUser(std::string u) { user = u; }
	void setPass(std::string p) { pass = p; }
	std::string getUser() { return user; }
	std::string getPass() { return pass; }

	std::string UserPass() {
		std::string loginInfo = getUser() + " " + getPass();
		return loginInfo;
	}

	void authCheck(std::string& loginInfo, bool& success) {
		userData.open("user.txt");
		if (userData.is_open())
		{
			while (std::getline(userData, line) && !success) {
				if (line.compare(loginInfo) == 0) {
					success = true;
				}
				else
					success = false;

			}
			userData.close();
			if (success)
			{
				return;
			}
			else
			{
				std::cout << "\nIncorrect Username or Password\n\n";
				loginInfo = "";
				login();
			}
			userData.close();
		}
		else
			std::cout << "Unable to open user.txt file.\n";
	}

	void login() {
		std::cout << "Sign into Space Invader\n\nUsername: ";
		std::cin >> user;
		std::cout << "Password: ";
		std::cin >> pass;
		setUser(user);
		setUser(pass);
	}
};
#endif