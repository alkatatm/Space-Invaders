#ifndef ENEMY_HPP
#define ENEMY_HPP
#include "Ship.hpp"
#include "ShipBullet.hpp"
#include "Score.hpp"
#include "Coord.hpp"
extern std::ofstream file;
/***************************************************
This class controls the enemies and collisions
The enemies move right to left
Check each  coordinate after if there's a collision
if so then stop moving
***************************************************/
class ENEMY : public COORD
{
private:
		 bool direction, alive;
		 SHIP& av;
		 SHIPBULLET& ab;
		 SCORE& s;
public:
	ENEMY(int _x, int _y, int _xMax, int _yMax, bool _direction, bool _alive, SHIP& _av,SHIPBULLET& _ab, SCORE& _s) : COORD(_x,_y,_xMax,_yMax), direction(_direction), alive(_alive), av(_av), ab(_ab), s(_s){}

	bool Alive() { return alive; }
	void Move(int junk) {
		if (alive) {
			if (direction) //left
			{
				minusX();
				checkCollision();
				if (getX() == 0) {
					direction = false;
					addY();
				}
			}
			else //right
			{
				addX();
				checkCollision();
				if (getX() == getXMAX()) {
					direction = true;
					addY();
				}
			}
		}
	}
	void checkCollision() {
		if (ab.getX() == getX() && ab.getY() == getY()) { ab.alive = false; alive = false; s.score += 100; }
		else if (av.getX() == getX() && av.getY() == getY()) { av.alive = false; alive = false; }
	}
	void display() {
		if (alive) {
			std::cout << "Enemy position at: " << getX() << " , " << getY() << std::endl;
			file << "Enemy position at: " << getX() << " , " << getY() << std::endl;
		}
		else {
			std::cout << "COLLIDED at: " << getX() << " , " << getY() << std::endl;
			file << "COLLIDED at: " << getX() << " , " << getY() << std::endl;
		}
	}
};
#endif